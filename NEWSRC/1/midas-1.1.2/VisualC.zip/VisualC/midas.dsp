# Microsoft Developer Studio Project File - Name="midas" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 5.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Dynamic-Link Library" 0x0102

CFG=midas - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "midas.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "midas.mak" CFG="midas - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "midas - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "midas - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 

# Begin Project
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "midas - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MT /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /Zp1 /MD /W3 /GX /O2 /I "..\..\SDL-1.0\include" /D "NDEBUG" /D "WIN32" /D "_WINDOWS" /D "__SDL__" /D "M_TRACKER" /D "M_DLL" /YX /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /o NUL /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /o NUL /win32
# ADD BASE RSC /l 0x409 /d "NDEBUG"
# ADD RSC /l 0x409 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib /nologo /subsystem:windows /dll /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib /nologo /subsystem:windows /dll /machine:I386

!ELSEIF  "$(CFG)" == "midas - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MTd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /Zp1 /MDd /W3 /Gm /GX /Zi /Od /I "..\..\SDL-1.0\include" /D "_DEBUG" /D "WIN32" /D "_WINDOWS" /D "__SDL__" /D "M_TRACKER" /D "M_DLL" /YX /FD /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /o NUL /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /o NUL /win32
# ADD BASE RSC /l 0x409 /d "_DEBUG"
# ADD RSC /l 0x409 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib /nologo /subsystem:windows /dll /debug /machine:I386 /pdbtype:sept
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib /nologo /subsystem:windows /dll /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "midas - Win32 Release"
# Name "midas - Win32 Debug"
# Begin Source File

SOURCE=..\adpcmtbl.c
# End Source File
# Begin Source File

SOURCE=..\dsm.c
# End Source File
# Begin Source File

SOURCE=..\dsm.h
# End Source File
# Begin Source File

SOURCE=..\dsmfilt.c
# End Source File
# Begin Source File

SOURCE=..\dsmmix.c
# End Source File
# Begin Source File

SOURCE=..\dsmnsnd.c
# End Source File
# Begin Source File

SOURCE=..\errors.c
# End Source File
# Begin Source File

SOURCE=..\errors.h
# End Source File
# Begin Source File

SOURCE=..\file.c
# End Source File
# Begin Source File

SOURCE=..\file.h
# End Source File
# Begin Source File

SOURCE=..\gmpcmds.c
# End Source File
# Begin Source File

SOURCE=..\gmplayer.c
# End Source File
# Begin Source File

SOURCE=..\gmplayer.h
# End Source File
# Begin Source File

SOURCE=..\it.h
# End Source File
# Begin Source File

SOURCE=..\lang.h
# End Source File
# Begin Source File

SOURCE=..\loadit.c
# End Source File
# Begin Source File

SOURCE=..\loadmod.c
# End Source File
# Begin Source File

SOURCE=..\loads3m.c
# End Source File
# Begin Source File

SOURCE=..\loadxm.c
# End Source File
# Begin Source File

SOURCE=..\madpcm.c
# End Source File
# Begin Source File

SOURCE=..\madpcm.h
# End Source File
# Begin Source File

SOURCE=..\mecho.c
# End Source File
# Begin Source File

SOURCE=..\mecho.h
# End Source File
# Begin Source File

SOURCE=..\mglobals.c
# End Source File
# Begin Source File

SOURCE=..\mglobals.h
# End Source File
# Begin Source File

SOURCE=..\midas.c
# End Source File
# Begin Source File

SOURCE=..\midas.h
# End Source File
# Begin Source File

SOURCE=..\midasdll.c
# End Source File
# Begin Source File

SOURCE=..\midasdll.h
# End Source File
# Begin Source File

SOURCE=..\midasfx.c
# End Source File
# Begin Source File

SOURCE=..\midasfx.h
# End Source File
# Begin Source File

SOURCE=..\midasrc.c
# End Source File
# Begin Source File

SOURCE=..\midasrc.h
# End Source File
# Begin Source File

SOURCE=..\midasstr.c
# End Source File
# Begin Source File

SOURCE=..\midasstr.h
# End Source File
# Begin Source File

SOURCE=..\midastrk.c
# End Source File
# Begin Source File

SOURCE=..\midastrk.h
# End Source File
# Begin Source File

SOURCE=..\mix_mf.c
# End Source File
# Begin Source File

SOURCE=..\mix_mfi.c
# End Source File
# Begin Source File

SOURCE=..\mix_mi.c
# End Source File
# Begin Source File

SOURCE=..\mix_sf.c
# End Source File
# Begin Source File

SOURCE=..\mix_sfi.c
# End Source File
# Begin Source File

SOURCE=..\mix_si.c
# End Source File
# Begin Source File

SOURCE=..\mmem.c
# End Source File
# Begin Source File

SOURCE=..\mmem.h
# End Source File
# Begin Source File

SOURCE=..\mpoll.c
# End Source File
# Begin Source File

SOURCE=..\mpoll.h
# End Source File
# Begin Source File

SOURCE=..\mprof.h
# End Source File
# Begin Source File

SOURCE=..\mtypes.h
# End Source File
# Begin Source File

SOURCE=..\mulaw.c
# End Source File
# Begin Source File

SOURCE=..\mulaw.h
# End Source File
# Begin Source File

SOURCE=..\mutils.c
# End Source File
# Begin Source File

SOURCE=..\mutils.h
# End Source File
# Begin Source File

SOURCE=..\rawfile.c
# End Source File
# Begin Source File

SOURCE=..\rawfile.h
# End Source File
# Begin Source File

SOURCE=..\sdevice.h
# End Source File
# Begin Source File

SOURCE=..\sdl.c
# End Source File
# Begin Source File

SOURCE="..\..\Sdl-1.0\VisualC\Sdl\Debug\SDL.lib"
# End Source File
# Begin Source File

SOURCE="..\..\Sdl-1.0\VisualC\SDLmain\Debug\SDLmain.lib"
# End Source File
# Begin Source File

SOURCE=..\vu.c
# End Source File
# Begin Source File

SOURCE=..\vu.h
# End Source File
# Begin Source File

SOURCE=..\waveread.c
# End Source File
# Begin Source File

SOURCE=..\waveread.h
# End Source File
# Begin Source File

SOURCE=..\xm.h
# End Source File
# End Target
# End Project
